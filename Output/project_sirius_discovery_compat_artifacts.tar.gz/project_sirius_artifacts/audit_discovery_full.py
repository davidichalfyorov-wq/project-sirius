from pathlib import Path
import re, collections
root=Path('discovery_text/Discovery Freelancer 4.86.0')
src=Path('src_bundle')
freelancer=root/'EXE/freelancer.ini'
file_index={p.relative_to(root).as_posix().lower():p for p in root.rglob('*') if p.is_file()}
def ci_path(rel):
    rel=rel.replace('\\','/').lstrip('./')
    return file_index.get(rel.lower(), root/rel)
def strip_comment(line): return line.split(';',1)[0].strip()
def parse_sections(path):
    cur=None; secs=[]
    try: lines=path.read_text(errors='replace').splitlines()
    except FileNotFoundError: return []
    for i,line in enumerate(lines,1):
        s=strip_comment(line)
        if not s: continue
        if s.startswith('[') and ']' in s:
            cur=s[1:s.index(']')].strip(); secs.append((cur,i,[]))
        elif cur and '=' in s:
            k,v=s.split('=',1); secs[-1][2].append((k.strip(),v.strip(),i))
        elif cur: secs[-1][2].append((s,'',i))
    return secs
def parse_data_entries(path):
    entries=[]
    for name,ln,ents in parse_sections(path):
        if name.lower()=='data':
            for k,v,i in ents: entries.append((k.lower(),v,i))
    return entries
def norm_data_path(v): return ci_path('DATA/' + v)

schema=src/'src/LibreLancer.Data/Schema'
class_entries=collections.defaultdict(set)
class_sections=collections.defaultdict(dict)
class_bases={}
parsed_ini_classes=set()
field_re=re.compile(r'public\s+(?:readonly\s+)?(?:(?:List<([\w\.]+)>\??)|(?:Dictionary<[^>]+>\??)|([\w\.]+)(?:\[\])?\??)\s+(\w+)')
section_re=re.compile(r'\[Section\("([^"]+)"(?:,\s*(?:typeof\((\w+)\)|Type\s*=\s*typeof\((\w+)\)))?')
entry_re=re.compile(r'\[Entry\("([^"]+)"')
handler_re=re.compile(r'\[EntryHandler\("([^"]+)"')
for p in schema.rglob('*.cs'):
    text=p.read_text(errors='replace')
    current=None; pending=[]
    if '[ParsedIni' in text:
        m=re.search(r'class\s+(\w+)', text)
        if m: parsed_ini_classes.add(m.group(1))
    for line in text.splitlines():
        cm=re.search(r'class\s+(\w+)\s*(?::\s*([\w\.]+))?', line)
        if cm:
            current=cm.group(1); pending=[]
            if cm.group(2): class_bases[current]=cm.group(2).split('.')[-1]
        if current:
            for em in entry_re.finditer(line): class_entries[current].add(em.group(1).lower())
            for hm in handler_re.finditer(line): class_entries[current].add(hm.group(1).lower())
            for sm in section_re.finditer(line):
                pending.append((sm.group(1).lower(), sm.group(2) or sm.group(3)))
            fm=field_re.search(line)
            if pending and fm:
                inferred=(fm.group(1) or fm.group(2) or '').split('.')[-1]
                for sec,typ in pending:
                    class_sections[current][sec]=typ or inferred
                pending=[]

def all_entries_for(cls):
    out=set(); seen=set()
    while cls and cls not in seen:
        seen.add(cls); out |= class_entries.get(cls,set()); cls=class_bases.get(cls)
    return out

def all_sections_for(cls):
    out={}; seen=set(); stack=[]
    c=cls
    while c and c not in seen:
        seen.add(c); stack.append(c); c=class_bases.get(c)
    for c in reversed(stack):
        out.update(class_sections.get(c,{}))
    return out
parsed_ini_sections={cls: all_sections_for(cls) for cls in parsed_ini_classes}

# Hand-written INI parsers are not discoverable from [ParsedIni]/[Section] attributes.
parsed_ini_sections.update({
    'AsteroidArchIni': {'asteroid': 'Asteroid', 'asteroidmine': 'Asteroid', 'dynamicasteroid': 'DynamicAsteroid'},
    'FontsIni': {'fontfiles': 'Manual', 'truetype': 'UIFont'},
    'GraphIni': {'igraph': 'Manual'},
    'PetalDbIni': {'objecttable': 'Manual'},
})

key_to_ini={'equipment':'EquipmentIni','goods':'GoodsIni','markets':'MarketsIni','ships':'ShiparchIni','loadouts':'LoadoutsIni','solar':'SolararchIni','asteroids':'AsteroidArchIni','effects':'EffectsIni','explosions':'ExplosionsIni','fuses':'FuseIni','stars':'StararchIni','rich_fonts':'RichFontsIni','fonts':'FontsIni','petaldb':'PetalDbIni','newchardb':'NewCharDBIni','voices':'VoicesIni','igraph':'GraphIni','hud':'HudIni','weaponmoddb':'WeaponModDbIni','commodities_per_faction':'CommoditiesPerFactionIni'}
entries=parse_data_entries(freelancer)
bykey=collections.defaultdict(list)
for k,v,i in entries: bykey[k].append((v,i))
# Discovery fallback for commodities_per_faction
if ci_path('DATA/equipment/commodities_per_faction.ini').exists():
    bykey['commodities_per_faction'].append(('equipment\\commodities_per_faction.ini',0))
print('Data entries:',len(entries))
print('recognized audited data keys:', ', '.join(sorted(k for k in bykey if k in key_to_ini)))
print('\nReferenced path existence:')
missing_any=False
for k,vals in sorted(bykey.items()):
    missing=[]
    for v,i in vals:
        if not v: continue
        path=norm_data_path(v)
        if not path.exists(): missing.append((v,i))
    if missing:
        missing_any=True; print('MISSING',k,missing[:10])
print('all valued [Data] paths in text archive exist' if not missing_any else '')

def audit_file(path, ini_cls, label, csects, centries, files):
    smap=parsed_ini_sections.get(ini_cls,{})
    for sec,ln,ents in parse_sections(path):
        typ=smap.get(sec.lower())
        if typ is None:
            csects[(label,ini_cls,sec.lower())]+=1; files[(label,ini_cls,sec.lower())].add(path.relative_to(root).as_posix())
            continue
        known=all_entries_for(typ)
        for k,v,i in ents:
            if known and k.lower() not in known:
                centries[(label,ini_cls,sec.lower(),k.lower())]+=1; files[(label,ini_cls,sec.lower(),k.lower())].add(path.relative_to(root).as_posix())

csects=collections.Counter(); centries=collections.Counter(); files=collections.defaultdict(set)
for key,ini_cls in key_to_ini.items():
    for v,i in bykey.get(key,[]):
        p=norm_data_path(v)
        if p.exists(): audit_file(p,ini_cls,key,csects,centries,files)
print('\nUnknown sections in main referenced data groups:')
if not csects: print('none')
for key,n in csects.most_common(80): print(' ',key,n, sorted(files[key])[:3])
print('\nUnknown entries in main referenced data groups:')
if not centries: print('none')
for key,n in centries.most_common(120): print(' ',key,n, sorted(files[key])[:3])

# dependent discovery graph
universe=ci_path('DATA/universe/universe.ini')
systems=[]; bases=[]
for sec,ln,ents in parse_sections(universe):
    vals={k.lower():v for k,v,i in ents}
    if sec.lower()=='system' and 'file' in vals: systems.append(ci_path('DATA/universe/'+vals['file']))
    if sec.lower()=='base' and 'file' in vals: bases.append(ci_path('DATA/'+vals['file']))
rooms=[]; nebulas=[]; asteroids=[]; encounters=[]
for b in bases:
    for sec,ln,ents in parse_sections(b):
        vals={k.lower():v for k,v,i in ents}
        if sec.lower()=='room' and 'file' in vals: rooms.append(ci_path('DATA/'+vals['file']))
for s in systems:
    for sec,ln,ents in parse_sections(s):
        vals={k.lower():v for k,v,i in ents}
        if sec.lower()=='nebula' and 'file' in vals: nebulas.append(ci_path('DATA/'+vals['file']))
        if sec.lower()=='asteroids' and 'file' in vals: asteroids.append(ci_path('DATA/'+vals['file']))
        if sec.lower()=='encounterparameters' and 'filename' in vals: encounters.append(ci_path('DATA/'+vals['filename']))
print('\ndependent file counts:', 'systems',len(systems),'bases',len(bases),'rooms',len(rooms),'nebulas',len(nebulas),'asteroids',len(asteroids),'encounters',len(encounters))
missing=[p for p in systems+bases+rooms+nebulas+asteroids+encounters if not p.exists()]
print('missing dependent paths:', len(missing))
for p in missing[:20]: print('  ',p)
csects=collections.Counter(); centries=collections.Counter(); files=collections.defaultdict(set)
for p in systems: audit_file(p,'StarSystem','system',csects,centries,files)
for p in bases: audit_file(p,'Base','base',csects,centries,files)
for p in rooms: audit_file(p,'Room','room',csects,centries,files)
for p in nebulas: audit_file(p,'Nebula','nebula',csects,centries,files)
for p in asteroids: audit_file(p,'AsteroidField','asteroids',csects,centries,files)
for p in encounters: audit_file(p,'EncounterIni','encounter',csects,centries,files)
print('\nUnknown dependent sections:')
if not csects: print('none')
for key,n in csects.most_common(80): print(' ',key,n, sorted(files[key])[:3])
print('\nUnknown dependent entries:')
if not centries: print('none')
for key,n in centries.most_common(120): print(' ',key,n, sorted(files[key])[:3])
